import arcade as arc


ROW_COUNT = 9
COLUMN_COUNT = 13
CELL_WIDTH = 80
CELL_HEIGHT = 80
MARGIN = 2
DOP_YACHEIKA = 80
SCREEN_TITLE = "Шаблон"
SCREEN_WIDTH = (CELL_WIDTH + MARGIN) * COLUMN_COUNT + MARGIN
SCREEN_HEIGHT = (CELL_HEIGHT + MARGIN) * ROW_COUNT + MARGIN + DOP_YACHEIKA

def relative_to_absolute(x, y):
    column = x // (MARGIN + CELL_WIDTH)
    row = (y - DOP_YACHEIKA) // (MARGIN + CELL_WIDTH)
    return column, row


def absolute_to_relative(column, row):
    x = (MARGIN + CELL_WIDTH) * column + MARGIN + CELL_WIDTH // 2
    y = (MARGIN + CELL_WIDTH) * row + MARGIN + CELL_WIDTH // 2 + DOP_YACHEIKA
    return x, y


class City():
    def __init__(self, column, row, colour):
        self.column = column
        self.row = row
        self.colour = colour

