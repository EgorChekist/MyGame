import arcade as arc
import json

ROW_COUNT = 9
COLUMN_COUNT = 13
CELL_WIDTH = 80
CELL_HEIGHT = 80
MARGIN = 2
DOP_YACHEIKA = 80
SCREEN_TITLE = "Шаблон"
SCREEN_WIDTH = (CELL_WIDTH + MARGIN) * COLUMN_COUNT + MARGIN
SCREEN_HEIGHT = (CELL_HEIGHT + MARGIN) * ROW_COUNT + MARGIN + DOP_YACHEIKA

def relative_to_absolute(x, y):
    column = x // (MARGIN + CELL_WIDTH)
    row = (y - DOP_YACHEIKA) // (MARGIN + CELL_WIDTH)
    return column, row


def absolute_to_relative(column, row):
    x = (MARGIN + CELL_WIDTH) * column + MARGIN + CELL_WIDTH // 2
    y = (MARGIN + CELL_WIDTH) * row + MARGIN + CELL_WIDTH // 2 + DOP_YACHEIKA
    return x, y

class Unit(arc.sprite.Sprite):
    live_units = []
    def __init__(self, way, size):
        super().__init__(way, size)
        self.column = None
        self.row = None
        self.colour = None
        self.max_movement = 1
        self.movement = 0
        self.damage = 0
        self.cost = 1

    def get_stats(self):
        return self.movement

    def set_pos(self, column, row):
        self.column = column
        self.row = row

    def get_pos(self):
        return self.column, self.row

    def move_to(self, map, row, column, colour, game):
        if self.checking_coordinates(map.units_map, column, row):
            game.bonus_of_locations(map, column, row)
            game.location_anti_step = False
            self.column = column
            self.row = row
            x, y = absolute_to_relative(column, row)
            self.center_x = x
            self.center_y = y
            # print(row, column)
            self.change_colour(colour, column, map, row)
            return True

    def change_colour(self, colour, column, map, row):
        if map.units_map[row][column] == 'city' and colour != "WHITE":
            map.map[row][column] = 2 if colour == "BLUE" else 1
            if (column, row) == (map.center_city.column, map.center_city.row):
                map.center_city.colour = "BLUE" if colour == "BLUE" else "RED"
            elif (column, row) == (map.right_rock_city.column, map.right_rock_city.row):
                map.right_rock_city.colour = "BLUE" if colour == "BLUE" else "RED"
            elif (column, row) == (map.left_rock_city.column, map.left_rock_city.row):
                map.left_rock_city.colour = "BLUE" if colour == "BLUE" else "RED"
            elif (column, row) == (map.begin_red_city.column, map.begin_red_city.row):
                map.begin_red_city.colour = "BLUE" if colour == "BLUE" else "RED"
            elif (column, row) == (map.begin_blue_city.column, map.begin_blue_city.row):
                map.begin_blue_city.colour = "BLUE" if colour == "BLUE" else "RED"

    def checking_coordinates(self, map, column, row):
        self.stay_terrian_type = map[self.row][self.column]
        self.wish_terrian_type = map[row][column]

        if self.wish_terrian_type == 'rock':
            return False
        else:
            if self.column + 1 == column and self.row == row:
                return True
            elif self.column - 1 == column and self.row == row:
                return True
            elif self.column == column and self.row + 1 == row:
                return True
            elif self.column == column and self.row - 1 == row:
                return True
            else:
                return False

    def cheking_square_3x3(self, column, row):
        min_column = self.column - 1 if self.column > 0 else 0
        min_row = self.row - 1 if self.row > 0 else 0
        max_column = self.column + 1 if self.column < 12 else 12
        max_row = self.row + 1 if self.row < 8 else 8
        for i in range(min_column, max_column+1):
            for j in range(min_row, max_row+1):
                if (j,i) == (row, column):
                    return True
        return False

    def mountain_anti_attack(self, at_column, at_row, map):
        print("Координаты:")
        print(f"свой ряд: {self.column}")
        print(f"свой столбец: {self.row}")
        print(f"атаковательный ряд: {at_column}")
        print(f"атаковательный столбец: {at_row}")
        sr_column = (at_column + self.column)/2
        sr_row = (at_row + self.row)/2
        print(f"среднее арифм. ряда: {sr_column}")
        print(f"среднее арифм. столбца: {sr_row}")
        if ((int(sr_column) == sr_column) and (int(sr_row) == sr_row)) and map.units_map[int(sr_row)][int(sr_column)] == "rock":
            return False
        # elif map.units_map[int(sr_row)][int(sr_column)] == "rock" or map.units_map[int(sr_row)+1][int(sr_column)+1] == "rock":
        #     return False
        else:
            return True

    # Реализация движения
    def reset_movement(self):
        self.movement -= self.max_movement

    def attack_enemy(self, enemy, game):
        print(f"Цвет врага: {enemy.colour}, Цвет собственный: {self.colour}")
        if enemy.colour != self.colour and self.colour == "BLUE":
            if game.spend_blue_actions(1):
                game.moving_state = False
                print("Враг красный атакован")
                enemy.health -= self.damage
                print(enemy.health)
                if enemy.health <= 0:
                    del game.red_units[enemy]
                    game.actions()
                    game.city_murder(enemy.row, enemy.column)
                    enemy.kill()
            game.downthrow()
        elif enemy.colour != self.colour and self.colour == "RED":
            if game.spend_red_actions(1):
                game.moving_state= False
                print("Враг синий атакован")
                enemy.health -= self.damage
                print(enemy.health)
                if enemy.health <= 0:
                    del game.blue_units[enemy]
                    game.actions()
                    game.city_murder(enemy.row, enemy.column)
                    enemy.kill()
            game.downthrow()

class Warrior(Unit):
    def __init__(self, colour):
        blue_warrior = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Рыцарь синий.png"
        red_warrior = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Рыцарь красный.png"
        warrior = blue_warrior if colour == "BLUE" else red_warrior
        super().__init__(warrior, size=0.114)
        self.owner = "Me"
        self.column = None
        self.row = None
        self.colour = colour
        self.max_health = self.health = 500
        self.damage = 150
    def cheking_coordinates_for_enemy(self, column, row, enemy, game):
        if self.cheking_square_3x3(column, row):
            self.attack_enemy(enemy, game)





class Archer(Unit):
    def __init__(self, colour):
        blue_archer = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Лучник синий.png"
        red_archer = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Лучник красный.png"
        archer = blue_archer if colour == "BLUE" else red_archer
        super().__init__(archer, size=0.22)

        self.column = None
        self.row = None
        self.colour = colour
        self.max_health = self.health = 100
        self.damage = 150

    def cheking_square_5x5_without_angles(self, column, row):
        min_column = self.column - 2 if self.column > 0 else 0
        min_row = self.row - 2 if self.row > 0 else 0
        max_column = self.column + 2 if self.column < 12 else 12
        max_row = self.row + 2 if self.row < 8 else 8
        for i in range(min_column, max_column + 1):
            for j in range(min_row, max_row + 1):
                if not (self.column + 2, self.row + 2) == (j, i) or not (self.column - 2, self.row - 2) == (
                        j, i) or not (self.column - 2, self.row + 2) == (j, i) or not (self.column + 2,
                                                                                       self.row - 2) == (
                                                                                              j, i):
                    if (j, i) == (row, column):
                        return True
        return False

    def mountain_anti_attack(self, at_column, at_row, map):
        print("Координаты:")
        print(f"свой ряд: {self.column}")
        print(f"свой столбец: {self.row}")
        print(f"атаковательный ряд: {at_column}")
        print(f"атаковательный столбец: {at_row}")
        sr_column = (at_column + self.column) / 2
        sr_row = (at_row + self.row) / 2
        print(f"среднее арифм. ряда: {sr_column}")
        print(f"среднее арифм. столбца: {sr_row}")
        sr_column = (at_column + self.column) / 2
        sr_row = (at_row + self.row) / 2
        if ((int(sr_column) == sr_column) and (int(sr_row) == sr_row)) and map.units_map[int(sr_row)][int(sr_column)] == "rock":
            return False
        # elif map.units_map[int(sr_row)][int(sr_column)] == "rock" and map.units_map[int(sr_row)+1][int(sr_column)+1] == "rock":
        #     return False
        else:
            return True

    def cheking_coordinates_for_enemy(self, column, row, enemy, game):
        if self.mountain_anti_attack(column, row, game.map):
            if self.cheking_square_3x3(column, row):
                self.attack_enemy(enemy, game)

            elif self.cheking_square_5x5_without_angles(column, row):
                self.attack_enemy(enemy, game)


class Cavalry(Unit):
    def __init__(self, colour):
        blue_cavalry = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Всадник синий.png"
        red_cavalry = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Всадник красный.png"
        cavalry = blue_cavalry if colour == "BLUE" else red_cavalry
        super().__init__(cavalry, size=0.105)
        self.column = None
        self.row = None
        self.colour = colour
        self.max_health = self.health = 300
        self.damage = 250
        self.max_movement = 2
        self.cost = 0.5
        self.unit_steps = 0

    def cheking_coordinates_for_enemy(self, column, row, enemy, game):
        if self.cheking_square_3x3(column, row):
            self.attack_enemy(enemy, game)


class Magician(Unit):
    def __init__(self, colour):
        blue_magician = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Маг синий.png"
        red_magician = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Маг красный.png"
        magician = blue_magician if colour == "BLUE" else red_magician
        super().__init__(magician, size=0.1876)
        self.column = None
        self.row = None
        self.colour = colour
        self.max_health = self.health = 400
        self.damage = self.medicine = 200

    def cheking_coordinates_for_enemy(self, column, row, enemy, game):
        if self.mountain_anti_attack(column, row, game.map):
            if self.cheking_square_3x3(column, row):
                self.attack_enemy(enemy, game)

            else:
                if (self.column, self.row+2) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column, self.row-2) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column+2, self.row) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column-2, self.row) ==  (column, row):
                    self.attack_enemy(enemy, game)

    def attack_enemy(self, enemy, game):
        super().attack_enemy(enemy, game)
        if enemy.colour == self.colour and self.colour == "BLUE":
            if game.spend_blue_actions(1):
                print("Синий юнит исцелен")
                enemy.health += self.medicine
                if enemy.health > enemy.max_health:
                    enemy.health = enemy.max_health
                print(enemy.health)
            game.downthrow()
        elif enemy.colour == self.colour and self.colour == "RED":
            if game.spend_red_actions(1):
                print("Красный юнит исцелен")
                enemy.health += self.medicine
                if enemy.health > enemy.max_health:
                    enemy.health = enemy.max_health
                print(enemy.health)
            game.downthrow()




class Cannon(Unit):
    def __init__(self, colour):
        blue_cannon = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Пушка синяя.png"
        red_cannon = "C:\\Users\\User\\OneDrive\\Рабочий стол\\Документация\\Пушка красная.png"
        cannon = blue_cannon if colour == "BLUE" else red_cannon
        super().__init__(cannon, size=0.138)
        self.column = None
        self.row = None
        self.colour = colour
        self.max_health = self.health = 350
        self.damage = 300
        self.cost = 2



    def cheking_coordinates_for_enemy(self, column, row, enemy, game):
        if self.mountain_anti_attack(column, row, game.map):
            if self.cheking_square_3x3(column, row):
                self.attack_enemy(enemy, game)

            else:
                if (self.column, self.row+2) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column, self.row-2) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column+2, self.row) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column-2, self.row) ==  (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column + 2, self.row + 2) == (column, row) or\
                        (self.column - 2, self.row - 2) == (column, row) or\
                        (self.column - 2, self.row + 2) == (column, row) or\
                        (self.column + 2, self.row - 2) == (column, row):
                    self.attack_enemy(enemy, game)
                elif (self.column + 3, self.row) == (column, row) or (
                        self.column - 3 , self.row) == (column, row) or (
                        self.column, self.row + 3) == (column, row) or (
                        self.column, self.row - 3) == (column, row):
                    self.attack_enemy(enemy, game)


