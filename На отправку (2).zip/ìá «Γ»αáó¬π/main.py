import arcade as arc
import json
import arcade.color
import arcade.gui as arcgui
from Units import *
from Cities import *


ROW_COUNT = 9
COLUMN_COUNT = 13
CELL_WIDTH = 80
CELL_HEIGHT = 80
MARGIN = 2
DOP_YACHEIKA = 80
SCREEN_TITLE = "Шаблон"
SCREEN_WIDTH = (CELL_WIDTH + MARGIN) * COLUMN_COUNT + MARGIN
SCREEN_HEIGHT = (CELL_HEIGHT + MARGIN) * ROW_COUNT + MARGIN + DOP_YACHEIKA


def relative_to_absolute(x, y):
    column = x // (MARGIN + CELL_WIDTH)
    row = (y - DOP_YACHEIKA) // (MARGIN + CELL_WIDTH)
    return column, row


def absolute_to_relative(column, row):
    x = (MARGIN + CELL_WIDTH) * column + MARGIN + CELL_WIDTH // 2
    y = (MARGIN + CELL_WIDTH) * row + MARGIN + CELL_WIDTH // 2 + DOP_YACHEIKA
    return x, y


class GameMap:
    def __init__(self):
        self.map = []
        self.units_spawn = []
        self.begin_blue_city = City(1, 4, "BLUE")
        self.begin_red_city = City(11, 4, "RED")
        self.left_rock_city = City(3, 7, "WHITE")
        self.right_rock_city = City(9, 1, "WHITE")
        self.center_city = City(6, 4,"WHITE")
        self.cities = [self.begin_blue_city, self.begin_red_city, self.center_city, self.left_rock_city, self.right_rock_city]
        self.city_names = ["begin_blue_city", "begin_red_city", "center_city", "left_rock_city", "right_rock_city"]
        self.deserts = ((0,1), (1,1), (2,1), (3,1), (3,2), (4,2), (8,6), (9,6), (9,7), (10,7), (11,7), (12,7))
    # Настройка карты в соответсвии с оригиналом
    def setup_map(self):
        self.map = [[3, 6, 3, 6, 6, 6, 6, 5, 7, 7, 6, 3, 6],
                    [4, 4, 4, 4, 6, 5, 5, 3, 6, 0, 6, 3, 3],
                    [3, 6, 3, 4, 4, 3, 7, 7, 5, 7, 6, 5, 3],
                    [6, 6, 3, 3, 6, 6, 3, 3, 5, 3, 3, 5, 5],
                    [6, 2, 3, 5, 5, 6, 0, 6, 5, 5, 3, 1, 6]]
        for index in range(3, -1, -1):
            self.map.append(list(reversed(self.map[index])))
            # Карта которую должны видеть юниты
        self.units_map = [['forest', 'plain',  'forest', 'plain',  'plain',  'plain',  'plain',  'swamp',  'rock',  'rock',   'plain',   'forest', 'plain'],
                            ['desert', 'desert', 'desert', 'desert', 'plain',  'swamp',  'swamp',  'forest', 'plain', "city",   'plain',   'forest', 'forest'],
                            ['forest', 'plain',  'forest', 'desert', 'desert', 'forest', 'rock',   'rock',   'swamp', 'rock',   'plain',   'swamp',  'forest'],
                            ['plain',  'plain',  'forest', 'forest', 'plain',  'plain',  'forest', 'forest', 'swamp', 'forest', 'forest',  'swamp',  'swamp'],
                            ['plain',  "city",   'forest', 'swamp',  'swamp',  'plain',  "city",   'plain',  'swamp', 'swamp',  'forest',  "city",    'plain']]
        for index in range(3, -1, -1):
            self.units_map.append(list(reversed(self.units_map[index])))

    def get_sell_color(self, row, column):
        if self.map[row][column] == 0:
            color = arc.color.GHOST_WHITE
        elif self.map[row][column] == 1:
            color = arc.color.RED
        elif self.map[row][column] == 2:
            color = arc.color.BLUE
        if self.map[row][column] == 3:
            color = arc.color.FOREST_GREEN
        if self.map[row][column] == 4:
            color = arc.color.DESERT
        if self.map[row][column] == 5:
            color = arc.color.CARIBBEAN_GREEN
        if self.map[row][column] == 6:
            color = arc.color.YELLOW_GREEN
        if self.map[row][column] == 7:
            color = arc.color.PURPLE_MOUNTAIN_MAJESTY
        return color


class TextLabel(arcgui.UILabel):
    @property
    def text_color(self):
        return self.label.text_color

    @text_color.setter
    def text_color(self, value):
        self.label.text_color = value
        self.trigger_full_render()
        print("Отчет о цветном разнообразии")



class OurGame(arc.Window):
    moving_state = False
    spawn_state = False
    square_city_coord_x = 0
    square_city_coord_y = 0
    blue_units = {}
    red_units = {}
    city_colours = {}
    friend_unit = None
    enemy_unit = None
    city_colour = None
    blue_actions = 2
    red_actions = 0
    last_step = "BLUE"
    cavalry_anti_step = False
    location_anti_step = False
    check_once = True
    deserts_mans = []
    curfew = None
    city_murder_counter = 0

    def __init__(self, width, height, title):
        super().__init__(width, height, title)
        # self.setup()
        self.map = GameMap()
        self.units = arc.SpriteList()
        self.cities_sl = arc.SpriteList()
        self.uimanager = arcgui.UIManager()
        self.uimanager.enable()
        self.v_box = arcgui.UIBoxLayout(x=100, y= 110, vertical = False)
        # self.colour_text = TextLabel(text="color: ", width=0, x=0, y=0, text_color=arc.color.BLACK)
        # self.v_box.add(self.colour_text.with_space_around(left=20))
        # self.actions_text = TextLabel(text=f"actions: {self.blue_actions}", width=0, x=0, y=0, text_color=arc.color.BLACK)
        # self.v_box.add(self.actions_text.with_space_around(left=-47, right=-20, top=35))
        # self.colour_step = TextLabel(text="BLUE", width=0, x=0, y=0, text_color=arc.color.BLUE)
        # self.v_box.add(self.colour_step)
        self.colour_step_b = TextLabel(text="BLUE", width=0, x=0, y=0, text_color=arc.color.BLUE)
        self.colour_step_r = TextLabel(text="RED", width=0, x=0, y=0, text_color=arc.color.RED)
        warrior_button = arcgui.UIFlatButton(text="Spawn Warrior", width=80, x = 0, y = 0)
        self.v_box.add(warrior_button.with_space_around(left=20))
        archer_button = arcgui.UIFlatButton(text="Spawn Archer", width=70, x=0, y=0)
        self.v_box.add(archer_button.with_space_around(left=20))
        cavalry_button = arcgui.UIFlatButton(text="Spawn Cavalry", width=80, x=0, y=0)
        self.v_box.add(cavalry_button.with_space_around(left=20))
        magician_button = arcgui.UIFlatButton(text="Spawn Magician", width=90, x=0, y=0)
        self.v_box.add(magician_button.with_space_around(left=20))
        cannon_button = arcgui.UIFlatButton(text="Spawn Cannon", width=90, x=0, y=0)
        self.v_box.add(cannon_button.with_space_around(left=20))
        loading_button = arcgui.UIFlatButton(text="Reloading", width=105, x=0, y=0, style={"bg_color" : arc.color.LAVA})
        self.v_box.add(loading_button.with_space_around(left=20))
        self.schedule = arc.gui.UITextArea(width=400, height=50, text_color=arc.color.BLACK, text="", font="Constantia", font_size=11)
        self.v_box.add(self.schedule.with_space_around(left=20))
        self.uimanager.add(arcgui.UIAnchorWidget(anchor_x="center_x", anchor_y="center_y", child=self.v_box, align_x=40, align_y=-370))

        @warrior_button.event("on_click")
        def on_click_warrior(event):
            # print(f"Цвет города: {self.city_colour}, положение о статусе возможности сбора войск: {self.spawn_state}")
            print(f"Отчет о комендантском часе: {self.curfew}")
            print(f"Квадратные городские иксы: {self.square_city_coord_x}")
            print(f"Квадратные городские игреки: {self.square_city_coord_y}")
            if self.spawn_state and self.city_colour != "WHITE" and not self.curfew == (self.square_city_coord_x, self.square_city_coord_y):
                self.spawn_state = False
                if self.city_colour == "RED" and self.red_actions > 0:
                    self.spend_red_actions(1)
                    warrior = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour,  'Warrior')
                    self.actions()
                    self.red_units[warrior] = {"coords" : (warrior.center_x, warrior.center_y), "health" : warrior.health}
                    self.downthrow()
                elif self.city_colour == "BLUE" and self.blue_actions > 0:
                    self.spend_blue_actions(1)
                    warrior = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour,  'Warrior')
                    self.actions()
                    self.blue_units[warrior] = {"coords" : (warrior.center_x, warrior.center_y), "health" : warrior.health}
                    self.downthrow()
                self.saving()
                print(self.red_units)
                print(self.blue_units)
        @archer_button.event("on_click")
        def on_click_archer(event):
            print(f"Отчет о комендантском часе: {self.curfew}")
            print(f"Квадратные городские иксы: {self.square_city_coord_x}")
            print(f"Квадратные городские игреки: {self.square_city_coord_y}")
            if self.spawn_state and self.city_colour != "WHITE" and not self.curfew == (self.square_city_coord_x, self.square_city_coord_y):
                self.spawn_state = False
                if self.city_colour == "RED" and self.red_actions > 0:
                    self.spend_red_actions(1)
                    archer = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Archer')
                    self.actions()
                    self.red_units[archer] = {"coords" : (archer.center_x, archer.center_y), "health" : archer.health}
                    self.downthrow()
                elif self.city_colour == "BLUE" and self.blue_actions > 0:
                    self.spend_blue_actions(1)
                    archer = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Archer')
                    self.actions()
                    self.blue_units[archer] = {"coords" : (archer.center_x, archer.center_y), "health" : archer.health}
                    self.downthrow()
                self.saving()
                print(self.red_units)
                print(self.blue_units)
        @cavalry_button.event("on_click")
        def on_click_cavalry(event):
            print(f"Отчет о комендантском часе: {self.curfew}")
            print(f"Квадратные городские иксы: {self.square_city_coord_x}")
            print(f"Квадратные городские игреки: {self.square_city_coord_y}")
            if self.spawn_state and self.city_colour != "WHITE" and not self.curfew == (self.square_city_coord_x, self.square_city_coord_y):
                self.spawn_state = False
                if self.city_colour == "RED" and self.red_actions > 0:
                    self.spend_red_actions(1)
                    cavalry = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Cavalry')
                    self.actions()
                    self.red_units[cavalry] = {"coords" : (cavalry.center_x, cavalry.center_y), "health" : cavalry.health}
                    self.downthrow()
                elif self.city_colour == "BLUE" and self.blue_actions > 0:
                    self.spend_blue_actions(1)
                    cavalry = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Cavalry')
                    self.actions()
                    self.blue_units[cavalry] = {"coords" : (cavalry.center_x, cavalry.center_y), "health" : cavalry.health}
                    self.downthrow()
                self.saving()
                print(self.red_units)
                print(self.blue_units)
        @magician_button.event("on_click")
        def on_click_magician(event):
            print(f"Отчет о комендантском часе: {self.curfew}")
            print(f"Квадратные городские иксы: {self.square_city_coord_x}")
            print(f"Квадратные городские игреки: {self.square_city_coord_y}")
            if self.spawn_state and self.city_colour != "WHITE" and not self.curfew == (self.square_city_coord_x, self.square_city_coord_y):
                self.spawn_state = False
                if self.city_colour == "RED" and self.red_actions > 0:
                    self.spend_red_actions(1)
                    magician = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Magician')
                    self.actions()
                    self.red_units[magician] = {"coords" : (magician.center_x, magician.center_y), "health" : magician.health}
                    self.downthrow()
                elif self.city_colour == "BLUE" and self.blue_actions > 0:
                    self.spend_blue_actions(1)
                    magician = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Magician')
                    self.actions()
                    self.blue_units[magician] = {"coords" : (magician.center_x, magician.center_y), "h`ealth" : magician.health}
                    self.downthrow()
                self.saving()
                print(self.red_units)
                print(self.blue_units)
        @cannon_button.event("on_click")
        def on_click_cannon(event):
            print(f"Отчет о комендантском часе: {self.curfew}")
            print(f"Квадратные городские иксы: {self.square_city_coord_x}")
            print(f"Квадратные городские игреки: {self.square_city_coord_y}")
            if self.spawn_state and self.city_colour != "WHITE" and not self.curfew == (self.square_city_coord_x, self.square_city_coord_y):
                self.spawn_state = False
                if self.city_colour == "RED" and self.red_actions > 0:
                    self.spend_red_actions(1)
                    cannon = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Cannon')
                    self.actions()
                    self.red_units[cannon] = {"coords" : (cannon.center_x, cannon.center_y), "health" : cannon.health}
                    self.downthrow()
                elif self.city_colour == "BLUE" and self.blue_actions > 0:
                    self.spend_blue_actions(1)
                    cannon = self.add_unit(self.square_city_coord_x, self.square_city_coord_y, self.city_colour, 'Cannon')
                    self.actions()
                    self.blue_units[cannon] = {"coords" : (cannon.center_x, cannon.center_y), "health" : cannon.health}
                    self.downthrow()
                self.saving()
                print(self.red_units)
                print(self.blue_units)
        @loading_button.event("on_click")
        def on_click_reloading(event):
            self.demobilization_of_army()
            arc.draw_rectangle_filled(650, 450, 100, 100, color=arc.color.LAVA)
            self.loading()
            self.city_loading()
            self.actions_loading()

    def draw(self):
        self.units.draw()
        for unit in self.units:
            percent_health = self.health_engine(unit)
            # print(f"{percent_health}% - медицинская справка")
            health_shift = ((CELL_WIDTH-25)/100*percent_health - (CELL_WIDTH-25))/2
            arc.draw_rectangle_filled(unit.center_x+health_shift, unit.top+20, (CELL_WIDTH-25)/100*percent_health, 15, (231, 24, 66))
            arc.draw_rectangle_outline(unit.center_x, unit.top+20, CELL_WIDTH-25, 15, arc.color.BLACK)
            arc.draw_text(f" {unit.health}", unit.center_x+((CELL_WIDTH-25)//2)-21, unit.top+17.5, arc.color.BLACK, 7)
            arc.draw_text(f" {percent_health}%", unit.center_x-((CELL_WIDTH-25)//2)-3, unit.top+17.5, arc.color.BLACK, 7)


    def downthrow(self):
        self.friend_unit = None
        self.enemy_unit = None

    def add_unit(self, coord_x, coord_y, colour, type, health=None):
        types = ["Warrior", "Archer", "Cavalry", "Magician", "Cannon"]
        units = [Warrior, Archer, Cavalry, Magician, Cannon]
        if health is None:
            self.unit = units[types.index(type)](colour)
            rel_x, rel_y = absolute_to_relative(coord_x, coord_y)
            self.unit.set_pos(coord_x, coord_y)
            self.unit.center_x = rel_x
            self.unit.center_y = rel_y
            self.units.append(self.unit)
            return self.unit
        elif health is not None:
            for case in types:
                if case in type:
                    type = case
                    break
            self.unit = units[types.index(type)](colour)
            # print(f"Положение о камуфляже армии: {colour}")
            self.unit.health = health
            abs_x, abs_y = relative_to_absolute(coord_x, coord_y)
            self.unit.set_pos(abs_x, abs_y)
            self.unit.center_x = coord_x
            self.unit.center_y = coord_y
            self.units.append(self.unit)
            return self.unit


    def bonus_of_locations(self, map, column, row):
        self.stay_terrian_type = map.units_map[self.unit.row][self.unit.column]
        self.wish_terrian_type = map.units_map[row][column]

        if self.wish_terrian_type == "plain" and self.check_once:
            self.location_anti_step = True
            self.check_once = False
            print("РАВНИНА")
            if self.unit.colour == "RED":
                self.spend_red_actions(-1)
            elif self.unit.colour == "BLUE":
                self.spend_blue_actions(-1)
        elif (self.wish_terrian_type == "swamp" and self.stay_terrian_type  == "swamp") and self.check_once:
            print("БОЛОТО")
            self.location_anti_step = True
            self.check_once = False
            if self.unit.colour == "RED":
                self.spend_red_actions(-1)
            elif self.unit.colour == "BLUE":
                self.spend_blue_actions(-1)
        elif (self.wish_terrian_type == "desert") and self.stay_terrian_type != "desert" and self.check_once:
            print("ПУСТЫНЯ")
            self.check_once = False
            self.location_anti_step = True
            if self.unit.colour == "RED":
                self.spend_red_actions(-1)
            elif self.unit.colour == "BLUE":
                self.spend_blue_actions(-1)
        if (self.stay_terrian_type == "desert" and (self.blue_actions > 1 or self.red_actions > 1) and self.wish_terrian_type == "desert") or \
            (self.stay_terrian_type == "desert" and (self.blue_actions > 1 or self.red_actions > 1) and self.unit in self.deserts_mans):
            print("ИСТОЩЕНИЕ")
            self.deserts_mans.remove(self.unit)
            if self.unit.colour == "RED":
                self.spend_red_actions(1)
            elif self.unit.colour == "BLUE":
                self.spend_blue_actions(1)

    def update_units_coords(self):
        if self.last_step == "BLUE":
            for bu in self.blue_units:
                self.blue_units[bu] = {"coords":[bu.center_x, bu.center_y], "health" : bu.health}
        elif self.last_step == "RED":
            for ru in self.red_units:
                self.red_units[ru] = {"coords":[ru.center_x, ru.center_y], "health" : ru.health}

    def actions(self):
        self.update_units_coords()
        self.saving()
        self.city_saving()
        self.city_murder_counter = self.city_dropping(self.city_murder_counter)
        if self.blue_actions + self.red_actions == 0 and self.last_step == "BLUE":
            self.check_once = True
            self.red_actions = 2
            self.last_step = "RED"
            self.friend_unit = None
            self.enemy_unit = None
            self.v_box.remove(self.colour_step)
            self.colour_step = self.colour_step_r
            self.v_box.add(self.colour_step.with_space_around(left=20))
            self.actions_text.text = f"actions: {self.red_actions}"
            print(f"{self.red_actions} - Проверка смены действий с синего на красный ")
            self.deserts_mans_mistake()
        elif self.red_actions + self.blue_actions == 0 and self.last_step == "RED":
            self.check_once = True
            self. blue_actions = 2
            self.last_step = "BLUE"
            self.friend_unit = None
            self.enemy_unit = None
            self.v_box.remove(self.colour_step)
            self.colour_step = self.colour_step_b
            self.v_box.add(self.colour_step.with_space_around(left=20))
            self.actions_text.text = f"actions: {self.blue_actions}"
            print(f"{self.blue_actions} - Проверка смены действий с красного на синий ")
            self.deserts_mans_mistake()


        self.actions_saving()


    def spend_blue_actions(self, cost):
        if self.blue_actions > 0:
            self.blue_actions -= cost
            self.actions_text.text = f"actions: {self.blue_actions}"
            print(f"{self.blue_actions} - Трата голубых действий")
            return True
        else:
            self.actions()
    def spend_red_actions(self, cost):
        if self.red_actions > 0:
            self.red_actions -= cost
            self.actions_text.text = f"actions: {self.red_actions}"
            print(f"{self.red_actions} - Трата красных действий")
            return True
        else:
            self.actions()

    def deserts_mans_mistake(self):
        for unu in self.units:
            if (unu.column, unu.row) in self.map.deserts and unu not in self.deserts_mans:
                self.deserts_mans.append(unu)
                print("Десертная операция")

    def renewal_scrollabel(self):
        text_unit = ""
        for unit in self.units:
            percent = unit.health // (unit.max_health / 100)
            text_unit += f"| {unit.__class__.__name__} |"
            text_unit += f" {(unit.column, unit.row)} |"
            text_unit += f" HP: {(unit.health, percent)}% |"
            text_unit += f" {(unit.colour)} |"
            text_unit += "\n"
        self.schedule.text = text_unit


    def saving(self):
        blue_units = {}
        red_units = {}
        for uni, coords in self.blue_units.items():
            blue_units[str(uni)] = coords
        for uni, coords in self.red_units.items():
            red_units[str(uni)] = coords
        with open("blue_army.json", "w", encoding = "utf-8") as file:
            json.dump(blue_units, file)
        with open("red_army.json", "w", encoding = "utf-8") as file:
            json.dump(red_units, file)
        self.renewal_scrollabel()

    def loading(self):
        self.blue_units = {}
        self.red_units = {}
        blue_units = {}
        red_units = {}
        with open("blue_army.json", "r", encoding = "utf-8") as file:
            blue_units = json.load(file)
        with open("red_army.json", "r", encoding = "utf-8") as file:
            red_units = json.load(file)
        for type, settings in blue_units.items():
            soldier = self.add_unit(settings["coords"][0], settings["coords"][1], "BLUE", type, settings["health"])
            self.blue_units[soldier] = settings
        for type, settings in red_units.items():
            soldier = self.add_unit(settings["coords"][0], settings["coords"][1], "RED", type, settings["health"])
            self.red_units[soldier] = settings

    def city_saving(self):
        # print(self.map.cities)
        for i, city in enumerate(self.map.cities):
            self.city_colours[self.map.city_names[i]] = {"city_coords" : (city.column, city.row), "colour" : city.colour}
        with open("cities.json", "w", encoding="utf-8") as file:
            json.dump(self.city_colours, file)

    def city_loading(self):
        pass
        number = 0
        with open ("cities.json", "r", encoding = "utf-8") as file:
            self.city_colours = json.load(file)
        for city, parametres in self.city_colours.items():
            self.city_id = self.map.city_names.index(city)
            self.map.cities[self.city_id].column = parametres["city_coords"][0]
            self.map.cities[self.city_id].row = parametres["city_coords"][1]
            self.map.cities[self.city_id].colour = parametres["colour"]
            for i in range(9):
                for j in range(13):
                    if self.map.units_map[i][j] == "city":
                        number += 1
                        self.unit.change_colour(self.map.cities[self.city_id].colour, self.map.cities[self.city_id].column, self.map, self.map.cities[self.city_id].row)

    def actions_saving(self):
        save_actions = {"blue_actions":  self.blue_actions, "red_actions": self.red_actions}
        with open("actions.json", "w", encoding="utf-8") as file:
            json.dump(save_actions, file)

    def actions_loading(self):
        with open("actions.json", "r", encoding="utf-8") as file:
            save_actions = json.load(file)
            self.blue_actions = save_actions["blue_actions"]
            self.red_actions = save_actions["red_actions"]
            print(f"Отчет о кол-ве действий {self.blue_actions}, {self.red_actions}")

    def demobilization_of_army(self):
        for kill_b_unit in self.blue_units:
            kill_b_unit.kill()
        for kill_r_unit in self.red_units:
            kill_r_unit.kill()
        print("Отчёт о ликвидации армии")

    def health_engine(self, unit):
        percent = unit.health//(unit.max_health/100)
        return percent

    def cheking_integer(self, actions):
        if actions == 2.0 or actions == 1.0 or actions == 0.0:
            self.cavalry_anti_step = False
            print("Изменение положения анти-хода кавалерии")

    def setup(self):
        self.map.setup_map()

    def on_draw(self):
        arc.start_render()
        arc.set_background_color(arc.color.BLACK)
        for row in range(ROW_COUNT):
            for column in range(COLUMN_COUNT):
                color = self.map.get_sell_color(row, column)
                x, y = absolute_to_relative(column, row)
                arc.draw_rectangle_filled(x, y, CELL_WIDTH, CELL_HEIGHT, color)
        x2 = SCREEN_WIDTH // 2
        arc.draw_rectangle_filled(x2, 0, SCREEN_WIDTH, DOP_YACHEIKA * 2 - 1, arc.color.WHITE)
        self.uimanager.draw()
        self.draw()

    def cavalry_anti_invide_in_others_cells(self, x, y):
        (cav_coord_x, cav_coord_y) = relative_to_absolute(x, y)
        for cav_unit in self.units:
            if cav_unit != self.unit:
                (column, row) = (cav_unit.column, cav_unit.row)
                if (cav_coord_x, cav_coord_y) == (column, row):
                    return False
        return True

    def city_murder(self, x, y):
        if self.map.units_map[x][y] == "city":
            self.curfew = (y, x)
            self.city_murder_counter = 2

    def city_dropping(self, cmc):
        if cmc > 0:
            cmc -= 1
        if cmc == 0:
            self.curfew = None
        return cmc

    def on_mouse_press(self, x, y, button, modifiers):
        target = None
        for cit in self.map.cities:
            column, row = cit.column, cit.row
            coord_x, coord_y = relative_to_absolute(x, y)
            if column == coord_x and row == coord_y:
                self.square_city_coord_x = coord_x
                self.square_city_coord_y = coord_y
                self.city_colour = cit.colour
                target = cit
        for unt in self.units:
            column, row = unt.column, unt.row
            coord_x, coord_y = relative_to_absolute(x, y)
            # print(f"Великая проверка френд юни это {self.friend_unit} и енеме юнит это {self.enemy_unit} и самый ЮНТ который {unt}")
            # print(f"Проверка анти-хода {self.cavalry_anti_step}")
            # print(f" Проверк локатиыного анти-хода {self.location_anti_step}")
            # print(f"({column, row}) == ({coord_x, coord_y})")
            # if (column, row) == (coord_x, coord_y):
            #     print("TRUE - координаты")
            #     if (self.cavalry_anti_step == False or (isinstance(unt, Cavalry) and (self.friend_unit == unt))):
            #         print("TRUE - состояние кавалерии")
            #     else:
            #         print("False - состояние кавалерии")
            #         print(f"Отчет о состоянии юнита {unt}")
            #         print(f"Отчет о состоянии френд юнита {self.friend_unit}")
            #
            #     if (self.location_anti_step == False or (self.friend_unit == unt)):
            #         print("TRUE - состояние локативной кавалерии")
            #     else:
            #         print("False - состояние локативной кавалерии")


            if (column, row) == (coord_x, coord_y) and (self.cavalry_anti_step == False or (isinstance(unt, Cavalry) and (self.friend_unit == unt)) and (self.location_anti_step == False or (self.friend_unit == unt))):
                target = unt #вечный регистр юнитов
                print(f"Отчет о юните {target}")
                if self.friend_unit is None or self.friend_unit == unt:
                    self.friend_unit = unt
                    print(f"{unt} - Промежуточный отчет о френд юните")
                elif self.enemy_unit is None and self.friend_unit != unt:
                    self.enemy_unit = unt
                    if self.last_step is not self.enemy_unit.colour:
                        print(f"{unt} - Промежуточный отчет о енеми юните")
                        if self.unit.colour == "BLUE" and self.blue_actions > 0 and self.friend_unit != self.enemy_unit:
                                self.friend_unit.cheking_coordinates_for_enemy(coord_x, coord_y, self.enemy_unit, game)

                        elif self.unit.colour == "RED" and self.red_actions > 0 and self.friend_unit != self.enemy_unit:
                                self.friend_unit.cheking_coordinates_for_enemy(coord_x, coord_y, self.enemy_unit, game)
                    else:
                        self.downthrow()

                else:
                    self.friend_unit = None
                    self.enemy_unit = None
                    print("Отчет о сбросе")
                    self.actions()
                if target.colour == "BLUE" and target in self.blue_units:
                    self.blue_units[target] = {"coords" : (target.center_x, target.center_y), "health" : target.health}
                elif target.colour == "RED" and target in self.red_units:
                    self.red_units[target] = {"coords" : (target.center_x, target.center_y), "health" : target.health}
            elif (column, row) == (coord_x, coord_y) and self.friend_unit == None and self.cavalry_anti_step == True:
                self.friend_unit = unt

        # print(f"Цель: {target}")

        if issubclass(type(target), Unit) and not self.moving_state:
            # print("ВЫ КЛИКНУЛИ ПО ЮНИТУ! БОЕВАЯ ТРЕВОГА!")
            for un in self.units:
                column, row = un.column, un.row
                coord_x, coord_y = relative_to_absolute(x, y)
                if column == coord_x and row == coord_y:
                    # print("Я РОБОТАЮ")
                    self.moving_state = True
                    self.unit = un
        elif self.moving_state:
            # print(f"Положение о ходьбе {self.unit}")
            self.unit.movement += self.unit.max_movement
            column, row = relative_to_absolute(x, y)
            # print(self.map.units_map[row][column])
            # print(row, column)
            if self.unit.cost == 1 and self.cavalry_anti_step == False:
                if self.unit.colour == "RED" and self.red_actions > 0:
                    if self.unit.move_to(self.map, row, column, self.unit.colour, game):
                        self.spend_red_actions(self.unit.cost)
                elif self.unit.colour == "BLUE" and self.blue_actions > 0:
                    if self.unit.move_to(self.map, row, column, self.unit.colour, game):
                        self.spend_blue_actions(self.unit.cost)

            elif self.unit.cost == 0.5:
                if self.cavalry_anti_invide_in_others_cells(x, y):
                    if self.unit.colour == "RED" and self.red_actions > 0:
                        self.cavalry_anti_step = True
                        print("Ход красной кавалерии")
                        if self.unit.move_to(self.map, row, column, self.unit.colour, game):
                            self.spend_red_actions(self.unit.cost)
                        self.cheking_integer(self.red_actions)
                    elif self.unit.colour == "BLUE" and self.blue_actions > 0:
                        self.cavalry_anti_step = True
                        print("Ход синей кавалерии")
                        if self.unit.move_to(self.map, row, column, self.unit.colour, game):
                            self.spend_blue_actions(self.unit.cost)
                        self.cheking_integer(self.blue_actions)

            elif self.unit.cost == 2:
                if self.red_actions == 1 or self.blue_actions == 1:
                    self.moving_state = False
                elif self.unit.colour == "RED":
                    if self.unit.move_to(self.map, row, column, self.unit.colour, game):
                        self.spend_red_actions(self.unit.cost)
                elif self.unit.colour == "BLUE":
                    if self.unit.move_to(self.map, row, column, self.unit.colour, game):
                        self.spend_blue_actions(self.unit.cost)

            if self.unit.movement == self.unit.max_movement:
                self.unit.movement = 0
                self.actions()
                self.moving_state = False
        if isinstance(target, City):
            for ci in self.map.cities:
                column, row = ci.column, ci.row
                coord_x, coord_y = relative_to_absolute(x, y)
                # print(f" Координаты по факту касания: {coord_x}, {coord_y}")
                # print(f" Координаты города из списка: {column}, {row}")
                if column == coord_x and row == coord_y:
                    self.spawn_state = True



game = OurGame(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_TITLE)
game.setup()
arc.run()